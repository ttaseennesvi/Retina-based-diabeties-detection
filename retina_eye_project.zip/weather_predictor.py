# Interactive Weather Feel Predictor (Python)
# Minor Project in AI & DS - CLI Version

data = {
    10: "very cold",
    15: "cold",
    20: "pleasant",
    25: "comfortable",
    30: "warm",
    35: "hot",
    40: "very hot"
}

def predict_label(temp, data):
    # Calculate the distance between the user input temperature and each data point, 
    # then choose the closest label.
    if not data:
        return "unknown"
    closest_temp = min(data.keys(), key=lambda x: abs(x - temp))
    return data[closest_temp]

if __name__ == '__main__':
    try:
        user_temp = float(input("Enter today's temperature in °C: "))
        feel = predict_label(user_temp, data)
        print(f"\n At {user_temp}°C, today feels {feel}. Stay vibey ")
    except ValueError:
        print("Please enter a valid numeric temperature.")
