import os
import csv
import math
import random
from PIL import Image, ImageDraw

# Set seed for reproducible image generation
random.seed(42)

def generate_csv_data(filepath, num_records=500):
    """
    Generates a synthetic CSV file containing features of retina scans mapped to DR severity stages.
    Stages:
    0: Normal
    1: Mild NPDR
    2: Moderate NPDR
    3: Severe NPDR
    4: Proliferative DR
    """
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    
    headers = [
        "patient_id", 
        "vessel_density", 
        "hemorrhage_count", 
        "exudate_ratio", 
        "neovascularization_index", 
        "dr_stage"
    ]
    
    with open(filepath, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(headers)
        
        for i in range(num_records):
            patient_id = f"PAT_{1000 + i}"
            
            # Select stage based on simple probability distribution
            stage = random.choices([0, 1, 2, 3], weights=[0.3, 0.25, 0.25, 0.2])[0]
            
            # Add some overlap/variance to make it a realistic classification task
            if stage == 0:  # Normal
                vessel_density = random.uniform(0.06, 0.18)
                hem_count = random.randint(0, 2)
                exudate_ratio = random.uniform(0.001, 0.003)
                neo_index = random.uniform(0.0, 0.05)
            elif stage == 1:  # Mild
                vessel_density = random.uniform(0.06, 0.18)
                hem_count = random.randint(3, 8)
                exudate_ratio = random.uniform(0.001, 0.003)
                neo_index = random.uniform(0.0, 0.05)
            elif stage == 2:  # Low Risk (Moderate)
                vessel_density = random.uniform(0.06, 0.18)
                hem_count = random.randint(9, 15)
                exudate_ratio = random.uniform(0.004, 0.008)
                neo_index = random.uniform(0.0, 0.05)
            else:  # High Risk (Severe & Proliferative)
                vessel_density = random.uniform(0.06, 0.23)
                hem_count = random.randint(16, 60)
                exudate_ratio = random.uniform(0.010, 0.038)
                neo_index = random.uniform(0.0, 1.0)
                
            writer.writerow([patient_id, round(vessel_density, 4), hem_count, round(exudate_ratio, 4), round(neo_index, 4), stage])

    print(f"Generated synthetic training data: {filepath}")

def draw_synthetic_retina(filename, stage):
    """
    Generates a realistic synthetic fundus image using PIL.
    """
    os.makedirs(os.path.dirname(filename), exist_ok=True)
    
    width, height = 500, 500
    img = Image.new("RGB", (width, height), "black")
    draw = ImageDraw.Draw(img)
    
    # 1. Main Fundus background (orange-red disk)
    cx, cy = width // 2, height // 2
    r_fundus = 220
    draw.ellipse([cx - r_fundus, cy - r_fundus, cx + r_fundus, cy + r_fundus], fill=(190, 70, 25))
    
    # Add radial shading to the fundus to make it look 3D and organic (darker near edges)
    # We do a simple overlay of a few semi-transparent concentric rings
    for r in range(r_fundus, r_fundus - 50, -5):
        alpha = int((r_fundus - r) / 50.0 * 80)
        draw.ellipse([cx - r, cy - r, cx + r, cy + r], outline=(120, 30, 10), width=2)
        
    # 2. Draw Optic Disc (yellowish-orange spot, offset)
    od_cx, od_cy = cx - 110, cy + 10
    od_r = 30
    draw.ellipse([od_cx - od_r, od_cy - od_r, od_cx + od_r, od_cy + od_r], fill=(245, 205, 110))
    # Soft inner border for optic disc
    draw.ellipse([od_cx - od_r + 5, od_cy - od_r + 5, od_cx + od_r - 5, od_cy + od_r - 5], fill=(255, 225, 140))

    # 3. Draw blood vessels branching out of optic disc
    vessel_color = (120, 15, 10)  # dark reddish brown
    
    # Draw branches in various directions
    angles = [-80, -50, -25, 0, 25, 50, 80, 110, 140, 170, 200, 230, 260]
    for angle in angles:
        rad = math.radians(angle)
        points = [(od_cx, od_cy)]
        
        # Grow the vessel branch outwards
        curr_x, curr_y = od_cx, od_cy
        branch_len = random.randint(12, 18)
        step_len = 18.0
        
        for step in range(1, branch_len):
            # Add some waviness and direct them generally outwards
            wave = random.uniform(-0.3, 0.3)
            curr_x += step_len * math.cos(rad + wave)
            curr_y += step_len * math.sin(rad + wave)
            
            # Keep within the fundus boundary
            dist_to_center = math.sqrt((curr_x - cx)**2 + (curr_y - cy)**2)
            if dist_to_center < r_fundus - 15:
                points.append((int(curr_x), int(curr_y)))
            else:
                break
                
        if len(points) > 1:
            # Draw main branch
            draw.line(points, fill=vessel_color, width=random.randint(3, 5))
            
            # Generate sub-branches
            for i in range(2, len(points) - 2):
                if random.random() < 0.6:  # 60% chance of sub-branching
                    sub_points = [points[i]]
                    sub_angle = angle + random.choice([-35, 35])
                    sub_rad = math.radians(sub_angle)
                    sub_x, sub_y = points[i]
                    
                    for _ in range(random.randint(3, 7)):
                        sub_wave = random.uniform(-0.2, 0.2)
                        sub_x += 12 * math.cos(sub_rad + sub_wave)
                        sub_y += 12 * math.sin(sub_rad + sub_wave)
                        
                        sub_dist = math.sqrt((sub_x - cx)**2 + (sub_y - cy)**2)
                        if sub_dist < r_fundus - 10:
                            sub_points.append((int(sub_x), int(sub_y)))
                        else:
                            break
                            
                    if len(sub_points) > 1:
                        draw.line(sub_points, fill=vessel_color, width=random.randint(1, 2))

    # 4. Draw Macula (darker reddish area on the opposite side of optic disc)
    macula_cx, macula_cy = cx + 80, cy - 5
    macula_r = 35
    # Transparent dark red overlay
    draw.ellipse([macula_cx - macula_r, macula_cy - macula_r, macula_cx + macula_r, macula_cy + macula_r], fill=(150, 45, 15))

    # 5. Add stage-specific disease features (hemorrhages, exudates, and neovascularization)
    hem_count = 0
    exu_count = 0
    neo_vessel_count = 0
    
    if stage == 1:  # Mild
        hem_count = random.randint(4, 7)
        exu_count = 0
    elif stage == 2:  # Moderate
        hem_count = random.randint(12, 18)
        exu_count = random.randint(6, 12)
    elif stage == 3:  # Severe
        hem_count = random.randint(25, 45)
        exu_count = random.randint(16, 28)
    elif stage == 4:  # Proliferative
        hem_count = random.randint(50, 85)
        exu_count = random.randint(35, 60)
        neo_vessel_count = 10  # Neovascularization (extra messy capillaries)

    # Helper to check if coordinate is inside fundus circle
    def is_in_fundus(x, y):
        dist = math.sqrt((x - cx)**2 + (y - cy)**2)
        # Avoid drawing directly on optic disc or macula for clarity
        dist_to_od = math.sqrt((x - od_cx)**2 + (y - od_cy)**2)
        dist_to_mac = math.sqrt((x - macula_cx)**2 + (y - macula_cy)**2)
        return dist < r_fundus - 20 and dist_to_od > od_r + 10 and dist_to_mac > 10

    # Draw Hemorrhages: Dark red spots (dot hemorrhages)
    for _ in range(hem_count):
        for _ in range(100):  # Retry loop to find valid coordinate
            hx = random.randint(cx - r_fundus, cx + r_fundus)
            hy = random.randint(cy - r_fundus, cy + r_fundus)
            if is_in_fundus(hx, hy):
                h_rad = random.randint(2, 6)
                # Draw a dark red spot
                draw.ellipse([hx - h_rad, hy - h_rad, hx + h_rad, hy + h_rad], fill=(110, 10, 8))
                # Add a slightly softer outer rim for larger spots
                if h_rad > 4:
                    draw.ellipse([hx - h_rad + 1, hy - h_rad + 1, hx + h_rad - 1, hy + h_rad - 1], fill=(130, 15, 10))
                break
                
    # Draw Exudates: Bright yellowish-white spots (hard exudates)
    for _ in range(exu_count):
        for _ in range(100):
            ex = random.randint(cx - r_fundus, cx + r_fundus)
            ey = random.randint(cy - r_fundus, cy + r_fundus)
            if is_in_fundus(ex, ey):
                e_rad = random.randint(2, 7)
                # Exudates often cluster, draw cluster or single spot
                draw.ellipse([ex - e_rad, ey - e_rad, ex + e_rad, ey + e_rad], fill=(245, 245, 160))
                if random.random() < 0.4:  # draw tiny neighbor spot
                    nx = ex + random.randint(-8, 8)
                    ny = ey + random.randint(-8, 8)
                    if is_in_fundus(nx, ny):
                        draw.ellipse([nx - 2, ny - 2, nx + 2, ny + 2], fill=(240, 240, 170))
                break

    # Draw Neovascularization: Crowded, messy thin vessels near optic disc or center
    if neo_vessel_count > 0:
        for _ in range(neo_vessel_count):
            # Pick center or near-optic-disc starting point
            start_x = cx + random.randint(-80, 80)
            start_y = cy + random.randint(-80, 80)
            
            points = [(start_x, start_y)]
            curr_x, curr_y = start_x, start_y
            
            # Draw highly winding, fine, thin capillaries
            cap_angle = random.uniform(0, 2 * math.pi)
            for _ in range(random.randint(6, 12)):
                cap_angle += random.uniform(-0.7, 0.7)
                curr_x += int(8 * math.cos(cap_angle))
                curr_y += int(8 * math.sin(cap_angle))
                if is_in_fundus(curr_x, curr_y):
                    points.append((curr_x, curr_y))
                else:
                    break
            
            if len(points) > 1:
                # Thin capillaries are thin and bright red
                draw.line(points, fill=(140, 20, 10), width=1)
                
    img.save(filename)
    print(f"Generated synthetic retina image ({filename}) for stage {stage}")

def main():
    csv_path = os.path.join("data", "retina_features.csv")
    generate_csv_data(csv_path, 500)
    
    stages = {
        0: "normal.png",
        1: "mild.png",
        2: "moderate.png",
        3: "severe.png",
        4: "proliferative.png"
    }
    
    for stage, name in stages.items():
        sample_path = os.path.join("static", "samples", name)
        draw_synthetic_retina(sample_path, stage)

if __name__ == "__main__":
    main()