import os
import json
import pickle
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix

def train_and_evaluate():
    # Paths
    csv_path = os.path.join('data', 'retina_features.csv')
    models_dir = 'models'
    os.makedirs(models_dir, exist_ok=True)
    
    if not os.path.exists(csv_path):
        raise FileNotFoundError(f"Dataset not found at {csv_path}. Please run generate_data.py first.")
        
    # 1. Load data
    df = pd.read_csv(csv_path)
    
    # Features and Target
    feature_cols = ['vessel_density', 'hemorrhage_count', 'exudate_ratio', 'neovascularization_index']
    X = df[feature_cols]
    y = df['dr_stage']
    
    # Train-test split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
    
    # 2. Scale features
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    # Save Scaler
    scaler_path = os.path.join(models_dir, 'scaler.pkl')
    with open(scaler_path, 'wb') as f:
        pickle.dump(scaler, f)
    print(f"Scaler saved to {scaler_path}")
        
    # 3. Train Model
    clf = RandomForestClassifier(n_estimators=100, random_state=42, class_weight='balanced')
    clf.fit(X_train_scaled, y_train)
    
    # Save Model
    model_path = os.path.join(models_dir, 'dr_classifier.pkl')
    with open(model_path, 'wb') as f:
        pickle.dump(clf, f)
    print(f"Model saved to {model_path}")
    
    # 4. Evaluate Model
    y_pred = clf.predict(X_test_scaled)
    
    accuracy = accuracy_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred, average='weighted')
    recall = recall_score(y_test, y_pred, average='weighted')
    f1 = f1_score(y_test, y_pred, average='weighted')
    
    cm = confusion_matrix(y_test, y_pred)
    
    # Feature Importances
    importances = clf.feature_importances_
    
    # Prepare metrics payload for frontend
    metrics = {
        "accuracy": round(accuracy, 4),
        "precision": round(precision, 4),
        "recall": round(recall, 4),
        "f1_score": round(f1, 4),
        "confusion_matrix": cm.tolist(),  # nested list
        "feature_importances": {
            "vessel_density": round(float(importances[0]), 4),
            "hemorrhage_count": round(float(importances[1]), 4),
            "exudate_ratio": round(float(importances[2]), 4),
            "neovascularization_index": round(float(importances[3]), 4)
        },
        "sample_size": len(df),
        "test_size": len(X_test)
    }
    
    # Save metrics JSON
    metrics_path = os.path.join(models_dir, 'metrics.json')
    with open(metrics_path, 'w') as f:
        json.dump(metrics, f, indent=4)
        
    print(f"Metrics saved to {metrics_path}")
    print(f"Model Accuracy: {accuracy:.4f} | F1-Score: {f1:.4f}")
    
    return metrics

if __name__ == '__main__':
    train_and_evaluate()