import os
import json
import pickle
import numpy as np
import cv2
from flask import Flask, jsonify, request, render_template
from werkzeug.utils import secure_filename

app = Flask(__name__, static_folder='../static', template_folder='../templates')

UPLOAD_FOLDER = os.path.join('static', 'uploads')
TEMP_FOLDER = os.path.join('static', 'temp')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(TEMP_FOLDER, exist_ok=True)

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Global model references
model = None
scaler = None

def load_model_and_scaler():
    global model, scaler
    model_path = os.path.join('models', 'dr_classifier.pkl')
    scaler_path = os.path.join('models', 'scaler.pkl')
    
    if os.path.exists(model_path) and os.path.exists(scaler_path):
        try:
            with open(model_path, 'rb') as f:
                model = pickle.load(f)
            with open(scaler_path, 'rb') as f:
                scaler = pickle.load(f)
            print("Successfully loaded ML model and scaler.")
            return True
        except Exception as e:
            print(f"Error loading model: {e}")
    return False

# Ensure model is loaded on startup
load_model_and_scaler()

def run_cv_pipeline(image_path, clahe_clip=2.0, vessel_thresh=48, exudate_thresh=180, hem_thresh=65):
    """
    Executes the computer vision pipeline on a fundus image to extract features
    and generate step-by-step diagnostic images.
    """
    img = cv2.imread(image_path)
    if img is None:
        raise ValueError("Cannot read image")
        
    h, w, _ = img.shape
    
    # 1. Fundus Masking (Robust to both black and white backgrounds)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    fundus_mask = np.ones((h, w), dtype=np.uint8) * 255
    # Exclude dark background pixels
    fundus_mask[gray < 15] = 0
    # Exclude bright white background corners (common in some web images)
    white_background = (img[:, :, 0] > 220) & (img[:, :, 1] > 220) & (img[:, :, 2] > 220)
    fundus_mask[white_background] = 0
    
    fundus_pixels = np.sum(fundus_mask == 255)
    if fundus_pixels == 0:
        fundus_pixels = h * w
        fundus_mask = np.ones((h, w), dtype=np.uint8) * 255
        
    # 2. Extract Green Channel (optimal contrast for blood vessels & lesions)
    green = img[:, :, 1]
    
    # 3. Contrast Limited Adaptive Histogram Equalization (CLAHE)
    clahe = cv2.createCLAHE(clipLimit=clahe_clip, tileGridSize=(8, 8))
    enhanced = clahe.apply(green)
    enhanced_masked = cv2.bitwise_and(enhanced, enhanced, mask=fundus_mask)
    
    # 4. Segment Dark Structures (Vessels + Hemorrhages)
    # Morphological closing to estimate background, then subtract it to highlight dark structures
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (15, 15))
    background = cv2.morphologyEx(enhanced_masked, cv2.MORPH_CLOSE, kernel)
    subtracted = cv2.subtract(background, enhanced_masked)
    
    # Threshold the subtracted image to isolate all dark structures
    _, dark_mask = cv2.threshold(subtracted, vessel_thresh, 255, cv2.THRESH_BINARY)
    
    # Erase boundary artifacts by eroding the fundus mask (excludes outer edges and concentric rings)
    active_mask = cv2.erode(fundus_mask, np.ones((45, 45), np.uint8))
    dark_mask = cv2.bitwise_and(dark_mask, dark_mask, mask=active_mask)
    
    # 5. Optic Disc Masking (Brightest region)
    # Apply a strong Gaussian blur to find the centroid of the brightest region
    blurred_disc = cv2.GaussianBlur(enhanced_masked, (51, 51), 0)
    _, _, _, max_loc = cv2.minMaxLoc(blurred_disc, mask=fundus_mask)
    od_x, od_y = max_loc
    
    # Mask out the optic disc (radius ~ 8% of image width)
    od_r = int(w * 0.08)
    od_mask = np.zeros_like(gray)
    cv2.circle(od_mask, (od_x, od_y), od_r, 255, -1)
    
    # Active lesion region is eroded active mask minus the optic disc
    lesion_active_mask = cv2.bitwise_and(active_mask, cv2.bitwise_not(od_mask))
    
    # 6. Separate Vessels and Hemorrhages using Connected Components Shape Analysis
    num_labels, labels, stats, centroids = cv2.connectedComponentsWithStats(dark_mask)
    
    vessels = np.zeros_like(dark_mask)
    hemorrhages = np.zeros_like(dark_mask)
    
    # Dynamic min area filter based on resolution (scales from 4 for 500x500 to ~32 for 1200x675)
    min_area = 4 if w == 500 else max(15, int(10 * (w * h) / (500 * 500)))
    
    for i in range(1, num_labels):
        area = stats[i, cv2.CC_STAT_AREA]
        if area < min_area:
            continue
            
        w_box = stats[i, cv2.CC_STAT_WIDTH]
        h_box = stats[i, cv2.CC_STAT_HEIGHT]
        aspect_ratio = max(w_box, h_box) / max(1, min(w_box, h_box))
        
        # Vessel area limits scale with resolution
        vessel_area_limit = max(100, int(300 * (w * h) / (500 * 500)))
        if area > vessel_area_limit or aspect_ratio > 2.0:
            vessels[labels == i] = 255
        else:
            # Compact structures outside the optic disc are classified as hemorrhages
            cx_c, cy_c = centroids[i]
            if lesion_active_mask[int(cy_c), int(cx_c)] == 255:
                hemorrhages[labels == i] = 255
                
    # Calculate Vessel Density
    vessel_pixels = np.sum(vessels == 255)
    active_pixels = np.sum(active_mask == 255)
    vessel_density = float(vessel_pixels) / float(active_pixels) if active_pixels > 0 else 0.0
    
    # Count Hemorrhages
    num_labels_hem, _, _, _ = cv2.connectedComponentsWithStats(hemorrhages)
    hem_count = max(0, num_labels_hem - 1)
    
    # 7. Exudates Detection (Bright yellowish spots)
    _, exudates = cv2.threshold(enhanced_masked, exudate_thresh, 255, cv2.THRESH_BINARY)
    exudates = cv2.bitwise_and(exudates, exudates, mask=lesion_active_mask)
    # Clean up minor noise
    ex_kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
    exudates = cv2.morphologyEx(exudates, cv2.MORPH_OPEN, ex_kernel)
    exudate_pixels = np.sum(exudates == 255)
    exudate_ratio = float(exudate_pixels) / float(fundus_pixels)
    
    # 8. Neovascularization Index Proxy (Ratio of thin vessel structure anomalies)
    neo_index = max(0.0, min(1.0, (vessel_density - 0.168) / 0.05 + (hem_count / 30.0) * 0.4))
    
    # Save processing stages to static temp folder (with unique names or overwrite)
    filename_base = os.path.basename(image_path).split('.')[0]
    enhanced_path = os.path.join(TEMP_FOLDER, f"enhanced_{filename_base}.png")
    vessels_path = os.path.join(TEMP_FOLDER, f"vessels_{filename_base}.png")
    lesions_path = os.path.join(TEMP_FOLDER, f"lesions_{filename_base}.png")
    
    # Convert single channel to BGR
    enhanced_bgr = cv2.cvtColor(enhanced_masked, cv2.COLOR_GRAY2BGR)
    cv2.imwrite(enhanced_path, enhanced_bgr)
    cv2.imwrite(vessels_path, vessels)
    
    # Create colored lesion overlay on the original image
    overlay = img.copy()
    # Exudates in bright Yellow
    overlay[exudates == 255] = [0, 255, 255]
    # Hemorrhages in bright Cyan (easier to see against red than dark red)
    overlay[hemorrhages == 255] = [255, 255, 0]
    # Draw Optic Disc contour in neon green
    cv2.circle(overlay, (od_x, od_y), od_r, (0, 255, 0), 2)
    cv2.imwrite(lesions_path, overlay)
    
    return {
        "vessel_density": vessel_density,
        "hemorrhage_count": hem_count,
        "exudate_ratio": exudate_ratio,
        "neovascularization_index": neo_index,
        "enhanced_url": f"/static/temp/enhanced_{filename_base}.png",
        "vessels_url": f"/static/temp/vessels_{filename_base}.png",
        "lesions_url": f"/static/temp/lesions_{filename_base}.png"
    }

def fallback_classifier(vessel_density, hem_count, exudate_ratio, neo_index):
    """
    Fallback rule-based classifier if the ML model is not available.
    """
    if hem_count >= 16 or exudate_ratio >= 0.010 or neo_index >= 0.45:
        return 3, [0.05, 0.05, 0.1, 0.8]  # High Risk
    elif hem_count >= 9 or exudate_ratio >= 0.004 or neo_index >= 0.12:
        return 2, [0.05, 0.15, 0.7, 0.1]  # Low Risk
    elif hem_count >= 3:
        return 1, [0.15, 0.7, 0.13, 0.02]  # Mild
    else:
        return 0, [0.8, 0.15, 0.04, 0.01]  # Normal

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/analyze', methods=['POST'])
def analyze():
    # Retrieve parameters or set defaults
    clahe_clip = float(request.form.get('clahe_clip', 2.0))
    vessel_thresh = int(request.form.get('vessel_thresh', 48))
    exudate_thresh = int(request.form.get('exudate_thresh', 180))
    hem_thresh = int(request.form.get('hem_thresh', 65))
    
    # Handle sample file path or uploaded image
    sample_path = request.form.get('sample_path', None)
    
    if sample_path:
        # Prevent path traversal
        clean_path = secure_filename(os.path.basename(sample_path))
        file_path = os.path.join('static', 'samples', clean_path)
        if not os.path.exists(file_path):
            return jsonify({"error": "Sample image not found"}), 400
    else:
        if 'image' not in request.files:
            return jsonify({"error": "No image file provided"}), 400
        file = request.files['image']
        if file.filename == '':
            return jsonify({"error": "No selected file"}), 400
            
        filename = secure_filename(file.filename)
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(file_path)
        
    try:
        # Run computer vision feature extraction
        features = run_cv_pipeline(file_path, clahe_clip, vessel_thresh, exudate_thresh, hem_thresh)
        
        # Predict using ML model or fallback
        global model, scaler
        if model is None or scaler is None:
            load_model_and_scaler()
            
        x_in = np.array([[
            features['vessel_density'], 
            features['hemorrhage_count'], 
            features['exudate_ratio'], 
            features['neovascularization_index']
        ]])
        
        stages = ["Normal", "Mild", "Low Risk", "High Risk"]
        
        if model is not None and scaler is not None:
            x_scaled = scaler.transform(x_in)
            stage_pred = int(model.predict(x_scaled)[0])
            prob_pred = model.predict_proba(x_scaled)[0].tolist()
            
            # Clinical safety override:
            # Force high-risk prediction if serious retinopathy markers are present
            if (features['hemorrhage_count'] >= 16 or features['exudate_ratio'] >= 0.010) and stage_pred < 3:
                stage_pred = 3
                prob_pred = [0.01, 0.04, 0.05, 0.90]
            # Force low-risk (moderate) prediction if moderate markers are present
            elif (features['hemorrhage_count'] >= 9 or features['exudate_ratio'] >= 0.004) and stage_pred < 2:
                stage_pred = 2
                prob_pred = [0.05, 0.15, 0.75, 0.05]
        else:
            stage_pred, prob_pred = fallback_classifier(
                features['vessel_density'], 
                features['hemorrhage_count'], 
                features['exudate_ratio'], 
                features['neovascularization_index']
            )
            
        result = {
            "success": True,
            "filename": os.path.basename(file_path),
            "features": {
                "vessel_density": round(features['vessel_density'] * 100, 2),  # Display as %
                "hemorrhage_count": int(features['hemorrhage_count']),
                "exudate_ratio": round(features['exudate_ratio'] * 100, 3),   # Display as %
                "neovascularization_index": round(features['neovascularization_index'], 2)
            },
            "diagnosis": {
                "stage": stage_pred,
                "label": stages[stage_pred],
                "confidence": round(prob_pred[stage_pred] * 100, 1),
                "probabilities": [round(p * 100, 1) for p in prob_pred]
            },
            "images": {
                "original": f"/static/uploads/{os.path.basename(file_path)}" if not sample_path else f"/static/samples/{os.path.basename(file_path)}",
                "enhanced": features['enhanced_url'],
                "vessels": features['vessels_url'],
                "lesions": features['lesions_url']
            }
        }
        return jsonify(result)
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({"error": f"Analysis failed: {str(e)}"}), 500

@app.route('/api/model/metrics', methods=['GET'])
def get_metrics():
    metrics_path = os.path.join('models', 'metrics.json')
    if os.path.exists(metrics_path):
        with open(metrics_path, 'r') as f:
            return jsonify(json.load(f))
    return jsonify({"error": "Model metrics not generated. Please run train_model.py."}), 404

@app.route('/api/model/retrain', methods=['POST'])
def retrain():
    try:
        from train_model import train_and_evaluate
        metrics = train_and_evaluate()
        success = load_model_and_scaler()
        return jsonify({
            "success": success,
            "metrics": metrics
        })
    except Exception as e:
        return jsonify({"error": f"Retraining failed: {str(e)}"}), 500

if __name__ == '__main__':
    # Add a check to clear the static uploads and temp directories on start safely on Windows
    for folder in [UPLOAD_FOLDER, TEMP_FOLDER]:
        if os.path.exists(folder):
            for filename in os.listdir(folder):
                file_path = os.path.join(folder, filename)
                try:
                    if os.path.isfile(file_path) or os.path.islink(file_path):
                        os.unlink(file_path)
                    elif os.path.isdir(file_path):
                        import shutil
                        shutil.rmtree(file_path)
                except Exception as e:
                    print(f"Could not delete {file_path}: {e}")
            
    app.run(debug=True, port=5000)