// Global chart instances
let probabilityChart = null;
let featureImportanceChart = null;

// Selected scan state
let selectedFile = null;
let selectedSample = null;
let isSampleMode = false;

document.addEventListener('DOMContentLoaded', () => {
    // 1. Navigation Tabs Switching
    initTabs();

    // 2. Initialize Slider Value Handlers
    initSliders();

    // 3. Drag & Drop File Upload Handlers
    initUploadZone();

    // 4. Sample Retina Images Gallery Handlers
    initSampleGallery();

    // 5. Run AI Analysis Trigger
    initAnalysisTrigger();

    // 6. Load Initial Model Metrics & Render Analytics Charts
    loadModelMetrics();

    // 7. Retrain Model Event Handler
    initModelRetraining();
});

/* Tab Switching System */
function initTabs() {
    const navItems = document.querySelectorAll('.nav-item');
    const tabPanes = document.querySelectorAll('.tab-pane');
    const pageTitle = document.getElementById('page-title');
    const pageSubtitle = document.getElementById('page-subtitle');

    const tabMeta = {
        'dashboard': {
            title: 'AI Diagnostic Hub',
            subtitle: 'Upload patient fundus scans to run computer vision feature extraction and classification.'
        },
        'processor': {
            title: 'Computer Vision Processing Pipeline',
            subtitle: 'Inspect details of green channel extraction, adaptive contrast enhancement, and segmented lesions.'
        },
        'analytics': {
            title: 'Random Forest Model Analytics',
            subtitle: 'Review cross-validation metrics, feature importances, and confusion matrix from the trained model.'
        },
        'guide': {
            title: 'Clinical Diabetic Retinopathy Guide',
            subtitle: 'Learn about clinical symptoms, lesion definitions, and treatment guidelines for the five DR stages.'
        }
    };

    navItems.forEach(item => {
        item.addEventListener('click', () => {
            const targetTab = item.getAttribute('data-tab');

            // Toggle Nav Styling
            navItems.forEach(nav => nav.classList.remove('active'));
            item.classList.add('active');

            // Toggle Pane Visibility
            tabPanes.forEach(pane => {
                pane.classList.remove('active');
                if (pane.id === targetTab) {
                    pane.classList.add('active');
                }
            });

            // Update Header Meta
            if (tabMeta[targetTab]) {
                pageTitle.textContent = tabMeta[targetTab].title;
                pageSubtitle.textContent = tabMeta[targetTab].subtitle;
            }
        });
    });
}

/* Slider Controls & Live Updating Values */
function initSliders() {
    const sliders = [
        { id: 'clahe-clip', valId: 'val-clahe-clip', defaultVal: '2.0' },
        { id: 'vessel-thresh', valId: 'val-vessel-thresh', defaultVal: '48' },
        { id: 'exudate-thresh', valId: 'val-exudate-thresh', defaultVal: '180' },
        { id: 'hem-thresh', valId: 'val-hem-thresh', defaultVal: '65' }
    ];

    sliders.forEach(slider => {
        const inputEl = document.getElementById(slider.id);
        const valEl = document.getElementById(slider.valId);

        if (inputEl && valEl) {
            inputEl.addEventListener('input', (e) => {
                valEl.textContent = e.target.value;
            });
        }
    });

    // Reset parameters button
    const btnReset = document.getElementById('btn-reset-params');
    if (btnReset) {
        btnReset.addEventListener('click', () => {
            sliders.forEach(slider => {
                const inputEl = document.getElementById(slider.id);
                const valEl = document.getElementById(slider.valId);
                if (inputEl && valEl) {
                    inputEl.value = slider.defaultVal;
                    valEl.textContent = slider.defaultVal;
                }
            });
        });
    }
}

/* Upload Dropzone Management */
function initUploadZone() {
    const dropzone = document.getElementById('dropzone');
    const fileInput = document.getElementById('file-input');
    const previewArea = document.getElementById('dropzone-preview');
    const previewImg = document.getElementById('preview-image');
    const btnRemove = document.getElementById('btn-remove-file');
    const promptArea = dropzone.querySelector('.dropzone-prompt');
    const btnAnalyze = document.getElementById('btn-analyze');

    // Click trigger for file browsing
    dropzone.addEventListener('click', (e) => {
        // Prevent click if clicking remove button
        if (e.target.closest('#btn-remove-file') || e.target.closest('input')) return;
        fileInput.click();
    });

    // Drag-over styling
    ['dragenter', 'dragover'].forEach(eventName => {
        dropzone.addEventListener(eventName, (e) => {
            e.preventDefault();
            dropzone.classList.add('dragover');
        }, false);
    });

    ['dragleave', 'drop'].forEach(eventName => {
        dropzone.addEventListener(eventName, (e) => {
            e.preventDefault();
            dropzone.classList.remove('dragover');
        }, false);
    });

    // Drop handler
    dropzone.addEventListener('drop', (e) => {
        const dt = e.dataTransfer;
        const files = dt.files;
        if (files && files.length > 0) {
            handleFileSelection(files[0]);
        }
    });

    // File input change handler
    fileInput.addEventListener('change', (e) => {
        if (e.target.files && e.target.files.length > 0) {
            handleFileSelection(e.target.files[0]);
        }
    });

    // Remove selected file
    btnRemove.addEventListener('click', (e) => {
        e.stopPropagation();
        clearFileSelection();
    });

    function handleFileSelection(file) {
        if (!file.type.startsWith('image/')) {
            alert('Unsupported file type. Please upload a valid image (PNG, JPG, TIFF).');
            return;
        }
        selectedFile = file;
        isSampleMode = false;
        selectedSample = null;

        // Clear sample image selection highlights
        document.querySelectorAll('.sample-card').forEach(card => card.classList.remove('selected'));

        // Load preview
        const reader = new FileReader();
        reader.onload = (event) => {
            previewImg.src = event.target.result;
            promptArea.style.display = 'none';
            previewArea.style.display = 'block';
            btnAnalyze.disabled = false;
        };
        reader.readAsDataURL(file);
    }

    function clearFileSelection() {
        selectedFile = null;
        fileInput.value = '';
        previewImg.src = '';
        previewArea.style.display = 'none';
        promptArea.style.display = 'block';
        btnAnalyze.disabled = !selectedSample; // Only keep enabled if a sample is active
    }
}

/* Sample Image Select Gallery */
function initSampleGallery() {
    const sampleCards = document.querySelectorAll('.sample-card');
    const btnAnalyze = document.getElementById('btn-analyze');
    const dropzone = document.getElementById('dropzone');
    const previewArea = document.getElementById('dropzone-preview');
    const previewImg = document.getElementById('preview-image');
    const promptArea = dropzone.querySelector('.dropzone-prompt');

    sampleCards.forEach(card => {
        card.addEventListener('click', () => {
            // Select active highlight
            sampleCards.forEach(c => c.classList.remove('selected'));
            card.classList.add('selected');

            const sampleName = card.getAttribute('data-sample');
            selectedSample = sampleName;
            isSampleMode = true;
            selectedFile = null;

            // Show sample in dropzone preview area
            previewImg.src = `/static/samples/${sampleName}`;
            promptArea.style.display = 'none';
            previewArea.style.display = 'block';

            // Hide file remove button since it's a sample preset
            document.getElementById('btn-remove-file').style.display = 'none';

            btnAnalyze.disabled = false;
        });
    });
}

/* Analysis Request Pipeline */
function initAnalysisTrigger() {
    const btnAnalyze = document.getElementById('btn-analyze');
    const loader = document.getElementById('loader-overlay');
    
    // Results panels
    const placeholder = document.getElementById('results-placeholder');
    const resultsContainer = document.getElementById('results-container');
    
    // Metrics DOM references
    const diagBadge = document.getElementById('diag-badge');
    const diagConfidence = document.getElementById('diag-confidence');
    const gaugeFill = document.getElementById('gauge-fill');
    
    const featVesselDensity = document.getElementById('feat-vessel-density');
    const featHemorrhages = document.getElementById('feat-hem-count');
    const featExudates = document.getElementById('feat-exudate-ratio');
    const featNeoIndex = document.getElementById('feat-neo-index');
    
    const barVesselDensity = document.getElementById('bar-vessel-density');
    const barHemorrhages = document.getElementById('bar-hem-count');
    const barExudates = document.getElementById('bar-exudate-ratio');
    const barNeoIndex = document.getElementById('bar-neo-index');

    const recTitle = document.getElementById('recommendation-title');
    const recDesc = document.getElementById('recommendation-desc');
    const clinicalCard = document.getElementById('clinical-card');

    btnAnalyze.addEventListener('click', () => {
        if (!selectedFile && !selectedSample) return;

        // Build Payload
        const formData = new FormData();
        formData.append('clahe_clip', document.getElementById('clahe-clip').value);
        formData.append('vessel_thresh', document.getElementById('vessel-thresh').value);
        formData.append('exudate_thresh', document.getElementById('exudate-thresh').value);
        formData.append('hem_thresh', document.getElementById('hem-thresh').value);

        if (isSampleMode) {
            formData.append('sample_path', selectedSample);
        } else {
            formData.append('image', selectedFile);
        }

        // Show Loader Overlay
        loader.style.display = 'flex';

        fetch('/api/analyze', {
            method: 'POST',
            body: formData
        })
        .then(response => {
            if (!response.ok) throw new Error('Analysis request failed.');
            return response.json();
        })
        .then(data => {
            loader.style.display = 'none';
            if (data.error) {
                alert(data.error);
                return;
            }

            // Reveal results
            placeholder.style.display = 'none';
            resultsContainer.style.display = 'flex';

            // 1. Update Diagnosis Headers
            const stage = data.diagnosis.stage;
            diagBadge.textContent = data.diagnosis.label;
            
            // Clean old badge colors & apply new class
            diagBadge.className = 'result-badge';
            diagBadge.classList.add(`badge-stage-${stage}`);

            diagConfidence.textContent = `${data.diagnosis.confidence}%`;
            
            // Map stage to gauge filling percentage (12% to 87% representing classes)
            const fillWidths = [12, 37, 62, 87];
            gaugeFill.style.width = `${fillWidths[stage]}%`;
            
            // Colors matching styling.css variables
            const fillColors = [
                'hsl(152, 76%, 50%)', // Normal
                'hsl(178, 48%, 53%)', // Mild (Teal #5bc0be)
                'hsl(38, 92%, 50%)',  // Low Risk
                'hsl(4, 90%, 58%)'    // High Risk
            ];
            gaugeFill.style.backgroundColor = fillColors[stage];

            // 2. Update Numerical Features and Progress Bars
            featVesselDensity.textContent = `${data.features.vessel_density}%`;
            featHemorrhages.textContent = data.features.hemorrhage_count;
            featExudates.textContent = `${data.features.exudate_ratio}%`;
            featNeoIndex.textContent = data.features.neovascularization_index;

            // Map feature value scales to progress bars (max ranges for full representation)
            // Vessel density max normal is ~25%
            barVesselDensity.style.width = `${Math.min(100, (data.features.vessel_density / 22) * 100)}%`;
            // Hemorrhage max count range ~150
            barHemorrhages.style.width = `${Math.min(100, (data.features.hemorrhage_count / 140) * 100)}%`;
            // Exudate max ratio is ~10%
            barExudates.style.width = `${Math.min(100, (data.features.exudate_ratio / 8) * 100)}%`;
            // Neovascularization scale is 0.0 - 1.0
            barNeoIndex.style.width = `${data.features.neovascularization_index * 100}%`;

            // 3. Render Stage Visualizer Comparison Images
            document.getElementById('img-stage-1').src = data.images.original + '?t=' + new Date().getTime();
            document.getElementById('img-stage-2').src = data.images.enhanced + '?t=' + new Date().getTime();
            document.getElementById('img-stage-3').src = data.images.vessels + '?t=' + new Date().getTime();
            document.getElementById('img-stage-4').src = data.images.lesions + '?t=' + new Date().getTime();
            document.getElementById('processor-img-name').textContent = data.filename;

            // 4. Update Probability Chart
            renderProbabilityChart(data.diagnosis.probabilities);

            // 5. Update Clinical Directives Card
            const directives = getClinicalDirectives(stage);
            recTitle.textContent = directives.title;
            recDesc.textContent = directives.desc;
            
            // Clean recommendation boundary colors
            clinicalCard.className = 'glass-card clinical-card';
            clinicalCard.classList.add(`clinical-stage-${stage}`);

            // Ensure images have loaded layout and scroll to view
            resultsContainer.scrollIntoView({ behavior: 'smooth' });
        })
        .catch(err => {
            loader.style.display = 'none';
            alert(`Error: ${err.message}`);
        });
    });
}

/* Clinical Recommendation Lookup */
function getClinicalDirectives(stage) {
    const directives = {
        0: {
            title: "No Diabetic Retinopathy (Normal)",
            desc: "Retinal features indicate healthy vascular structures without exudate leakage or hemorrhaging. Action: Schedule regular annual eye exams and maintain optimal blood glucose and blood pressure controls."
        },
        1: {
            title: "Mild Diabetic Retinopathy",
            desc: "A small number of microaneurysms detected. Action: Repeat dilated eye exam in 6-12 months. Strict medical management of diabetes (HbA1c monitoring) and glycemic controls are advised to prevent lesion progression."
        },
        2: {
            title: "Moderate Diabetic Retinopathy (Low Risk)",
            desc: "Exudate spots and minor hemorrhages are present. Action: Consult an ophthalmologist for a comprehensive evaluation within 3-6 months. Review and optimize systemic diabetes therapies."
        },
        3: {
            title: "Severe / Proliferative Diabetic Retinopathy (High Risk)",
            desc: "Extensive hemorrhages, leaking lipid exudates, or neovascularization detected. High risk of visual impairment. Action: Urgent referral to a retina specialist within 1-2 weeks for evaluation of laser photocoagulation or anti-VEGF injection therapies."
        }
    };
    return directives[stage];
}

/* Render single scan prediction probability vector chart */
function renderProbabilityChart(probs) {
    const ctx = document.getElementById('probability-chart').getContext('2d');
    
    if (probabilityChart) {
        probabilityChart.destroy();
    }

    probabilityChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Normal', 'Mild', 'Low Risk', 'High Risk'],
            datasets: [{
                label: 'Prediction Confidence (%)',
                data: probs,
                backgroundColor: [
                    'rgba(16, 185, 129, 0.6)', // Normal (emerald)
                    'rgba(91, 192, 190, 0.6)',  // Mild (teal)
                    'rgba(245, 158, 11, 0.6)',  // Low Risk (yellow)
                    'rgba(239, 68, 68, 0.6)'    // High Risk (red)
                ],
                borderColor: [
                    'hsl(152, 76%, 50%)',
                    'hsl(178, 48%, 53%)',
                    'hsl(38, 92%, 50%)',
                    'hsl(4, 90%, 58%)'
                ],
                borderWidth: 1.5,
                borderRadius: 6
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    grid: { color: 'rgba(255, 255, 255, 0.05)' },
                    ticks: { color: 'rgba(255, 255, 255, 0.6)', font: { family: 'Outfit' } }
                },
                x: {
                    grid: { display: false },
                    ticks: { color: 'rgba(255, 255, 255, 0.8)', font: { family: 'Outfit', weight: 500 } }
                }
            }
        }
    });
}

/* Load ML model metrics & render charts */
function loadModelMetrics() {
    fetch('/api/model/metrics')
    .then(response => {
        if (!response.ok) throw new Error('Could not retrieve model metrics.');
        return response.json();
    })
    .then(data => {
        // Populate performance cards
        document.getElementById('model-dataset-size').textContent = data.sample_size;
        document.getElementById('model-accuracy').textContent = `${(data.accuracy * 100).toFixed(1)}%`;
        document.getElementById('model-f1-score').textContent = `${(data.f1_score * 100).toFixed(1)}%`;

        // Render Feature Importances Chart
        renderFeatureImportance(data.feature_importances);

        // Render Confusion Matrix heatmap table
        renderConfusionMatrixTable(data.confusion_matrix);
    })
    .catch(err => {
        console.warn('Metrics failed to load. The model might not be trained yet: ', err);
    });
}

/* Render feature importance chart */
function renderFeatureImportance(importances) {
    const ctx = document.getElementById('feature-importance-chart').getContext('2d');
    
    if (featureImportanceChart) {
        featureImportanceChart.destroy();
    }

    const labels = {
        vessel_density: 'Vessel Density',
        hemorrhage_count: 'Hemorrhage Count',
        exudate_ratio: 'Exudates Ratio',
        neovascularization_index: 'Neovascularization'
    };

    const sortedFeatures = Object.entries(importances).sort((a, b) => b[1] - a[1]);
    const chartLabels = sortedFeatures.map(item => labels[item[0]] || item[0]);
    const chartValues = sortedFeatures.map(item => item[1] * 100); // convert to %

    featureImportanceChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: chartLabels,
            datasets: [{
                label: 'Relative Weight (%)',
                data: chartValues,
                backgroundColor: 'rgba(0, 150, 255, 0.55)',
                borderColor: 'hsl(200, 100%, 50%)',
                borderWidth: 1.5,
                borderRadius: 6
            }]
        },
        options: {
            indexAxis: 'y', // Horizontal bars
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                x: {
                    beginAtZero: true,
                    max: 100,
                    grid: { color: 'rgba(255, 255, 255, 0.05)' },
                    ticks: { color: 'rgba(255, 255, 255, 0.6)', font: { family: 'Outfit' } }
                },
                y: {
                    grid: { display: false },
                    ticks: { color: 'rgba(255, 255, 255, 0.8)', font: { family: 'Outfit', weight: 500 } }
                }
            }
        }
    });
}

/* Populate confusion matrix HTML table heatmap style */
function renderConfusionMatrixTable(matrix) {
    const tableBody = document.querySelector('#cm-table tbody');
    if (!tableBody) return;

    tableBody.innerHTML = '';
    const classLabels = ['Nor', 'Mil', 'Low', 'High'];
    const classTooltips = ['Normal', 'Mild', 'Low Risk', 'High Risk'];

    // Find the maximum value in matrix to compute relative opacities
    let maxVal = 1;
    matrix.forEach(row => {
        row.forEach(val => {
            if (val > maxVal) maxVal = val;
        });
    });

    for (let i = 0; i < matrix.length; i++) {
        const row = document.createElement('tr');
        
        // Row label (True Class)
        const rowHeader = document.createElement('th');
        rowHeader.textContent = `True: ${classLabels[i]}`;
        rowHeader.title = classTooltips[i];
        row.appendChild(rowHeader);

        for (let j = 0; j < matrix[i].length; j++) {
            const cell = document.createElement('td');
            const cellVal = matrix[i][j];
            cell.textContent = cellVal;
            
            // Highlight styling
            if (i === j) {
                // Diagonal elements (correct predictions) get Green heat shading
                cell.className = 'diag-cell';
                const opacity = (cellVal / maxVal) * 0.7 + 0.15; // Min 0.15 to show light green, max 0.85
                cell.style.background = `rgba(16, 185, 129, ${opacity})`;
                cell.style.border = '1px solid rgba(16, 185, 129, 0.4)';
            } else {
                // Off-diagonal elements (incorrect predictions/errors) get Red heat shading if > 0
                if (cellVal > 0) {
                    const opacity = (cellVal / maxVal) * 0.7 + 0.1;
                    cell.style.background = `rgba(239, 68, 68, ${opacity})`;
                    cell.style.color = '#fff';
                    cell.style.fontWeight = 'bold';
                    cell.style.border = '1px solid rgba(239, 68, 68, 0.4)';
                } else {
                    cell.style.background = 'rgba(255, 255, 255, 0.02)';
                    cell.style.color = 'rgba(255, 255, 255, 0.2)';
                }
            }
            row.appendChild(cell);
        }
        tableBody.appendChild(row);
    }
}

/* Model Retraining System */
function initModelRetraining() {
    const btnRetrain = document.getElementById('btn-retrain');
    const loader = document.getElementById('loader-overlay');
    const loaderTitle = loader.querySelector('h3');
    const loaderText = loader.querySelector('p');

    if (!btnRetrain) return;

    btnRetrain.addEventListener('click', () => {
        // Toggle loader text to indicate model retraining state
        loaderTitle.textContent = "Retraining Random Forest Model...";
        loaderText.textContent = "Recalculating feature thresholds, splitting dataset, and rebuilding decision trees.";
        loader.style.display = 'flex';

        fetch('/api/model/retrain', {
            method: 'POST'
        })
        .then(response => {
            if (!response.ok) throw new Error('Model retraining request failed.');
            return response.json();
        })
        .then(data => {
            // Restore default loader text
            loaderTitle.textContent = "Analyzing Retina Scan...";
            loaderText.textContent = "Applying green channel filtering, contrast equalization, and ML diagnostic scoring.";
            loader.style.display = 'none';

            if (data.error) {
                alert(data.error);
                return;
            }

            alert("Random Forest model trained successfully! Refreshing analytics dashboard.");
            
            // Reload metrics and redraw charts
            loadModelMetrics();
        })
        .catch(err => {
            loaderTitle.textContent = "Analyzing Retina Scan...";
            loaderText.textContent = "Applying green channel filtering, contrast equalization, and ML diagnostic scoring.";
            loader.style.display = 'none';
            alert(`Error: ${err.message}`);
        });
    });
}